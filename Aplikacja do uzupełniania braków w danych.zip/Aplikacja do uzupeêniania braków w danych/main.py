import tkinter as tk
from ui.layout import ExcelViewerApp

if __name__ == "__main__":
    root = tk.Tk()
    app = ExcelViewerApp(root)
    root.mainloop()
